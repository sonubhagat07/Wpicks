
WPick Website - How to Edit

1. Replace the 'https://your-affiliate-link-here' in index.html with your Amazon affiliate link.
2. Change the product image (product.jpg) to your real product image.
3. Customize the title and description inside <h2> and <p> tags.
4. You can duplicate the <section class="product-card"> block to add more products.

Hosted with ❤️ by Sonu × AISO
